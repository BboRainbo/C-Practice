﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 披薩分類
{
    internal class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                bool flag = false;
                Console.WriteLine("請輸入溫度(度C)");
                double temp = double.Parse(Console.ReadLine());
                Console.WriteLine("請輸入濕度(%)");
                double wet = double.Parse(Console.ReadLine());

                if (125 > temp && temp > 120)
                {
                    if (7 > wet && wet > 5)
                    {
                        Console.WriteLine("Good Pizza!");
                    }
                    else Console.WriteLine("bad pizza!");
                }
                else Console.WriteLine("bad pizza!");
                Console.WriteLine("請按任意鍵繼續");
                Console.ReadLine();
            }
        }
    }
}
